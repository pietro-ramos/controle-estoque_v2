-- Tabela Fornecedor
CREATE TABLE "Fornecedor" (
  "id" SERIAL,
  "cnpj" VARCHAR(20) NOT NULL,
  "name" VARCHAR(100) NOT NULL,
  "email" VARCHAR(100),
  CONSTRAINT "pkFornecedor" PRIMARY KEY ("id"),
  CONSTRAINT "uqFornecedorCNPJ" UNIQUE ("cnpj")
);

DROP TABLE "Fornecedor";

-- Tabela Produto
CREATE SEQUENCE "Produto_SEQ" AS INT
    INCREMENT BY 1
    START WITH 1;

CREATE TABLE "Produto" (
   "id" INT DEFAULT nextval('"Produto_SEQ"'),
   "name" VARCHAR(100) NOT NULL,
   "price" DECIMAL(10, 2) NOT NULL,
   "supplier_id" INT,
   "estoque_total" INT DEFAULT 0,
   CONSTRAINT "pkProduto" PRIMARY KEY ("id"),
   CONSTRAINT "fkProdutoFornecedor" FOREIGN KEY ("supplier_id") REFERENCES "Fornecedor" ("id")
       ON DELETE SET NULL
       ON UPDATE CASCADE
);

DROP TABLE "Produto";
DROP SEQUENCE "Produto_SEQ";

-- Tabela Movimentacao_Estoque
CREATE TABLE "Movimentacao_Estoque" (
    "id" SERIAL,
    "date" DATE NOT NULL,
    "type" VARCHAR(20) NOT NULL,
    "quantity" INT NOT NULL,
    "product_id" INT NOT NULL,
    CONSTRAINT "pkMovimentacaoEstoque" PRIMARY KEY ("id"),
    CONSTRAINT "fkMovimentacaoProduto" FOREIGN KEY ("product_id") REFERENCES "Produto"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT "ckMovimentacaoType" CHECK ("type" IN ('ADJUSTMENT', 'PURCHASE', 'SALE')),
    CONSTRAINT "ckMovimentacaoQuantity" CHECK ("quantity" > 0)
);

DROP TABLE "Movimentacao_Estoque";

-- Tabela BarCode
CREATE TABLE "BarCode" (
   "id" SERIAL,
   "code" VARCHAR(50) NOT NULL,
   "product_id" INT NOT NULL,
   CONSTRAINT "pkBarCode" PRIMARY KEY ("id"),
   CONSTRAINT "uqBarCodeCode" UNIQUE ("code"),
   CONSTRAINT "fkBarCodeProduto" FOREIGN KEY ("product_id") REFERENCES "Produto"("id")
       ON DELETE CASCADE
       ON UPDATE CASCADE
);

DROP TABLE "BarCode";
