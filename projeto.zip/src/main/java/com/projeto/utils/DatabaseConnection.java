package com.projeto.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe para criar e gerenciar a conexão com o banco de dados PostgreSQL.
 */
public class DatabaseConnection {
    private static final String URL = "jdbc:postgresql://localhost:5432/projeto";
    private static final String USER = "postgres";
    private static final String PASSWORD = "postgres";

    private static Connection connection;

    // Construtor privado para evitar instâncias
    private DatabaseConnection() {}

    /**
     * Obtém uma conexão com o banco de dados.
     *
     * @return a conexão ao banco de dados.
     * @throws SQLException se houver um erro ao conectar.
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        }
        return connection;
    }

    /**
     * Define uma conexão para testes.
     *
     * @param connection a conexão a ser definida.
     */
    public static void setConnection(Connection connection) {
        DatabaseConnection.connection = connection;
    }
}
